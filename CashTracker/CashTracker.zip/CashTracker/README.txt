CashTracker Console Application by Blake Bordovsky
7/18/2015

Application written in Python 2.7

Windows Installation:
1. If not installed, install Python 2.7 with included python-2.7.10.msi
2. Setup CashTracker.csv with items in column A and price in column B

Other installation:
1. Get Python 2.7 release for appropriate OS:
   https://www.python.org/downloads/release/python-2710/
2. Setup CashTracker.csv with items in column A and price in column B
   
Run CashTracker.pyc

I can be contacted at: BlakeBordovsky@gmail.com