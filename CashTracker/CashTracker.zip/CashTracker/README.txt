Windows Installation:
1. If not installed, install Python 2.7 with python-2.7.10.msi
2. Setup CashTracker.csv with items in column A and price in column B
3. run CashTracker.pyc